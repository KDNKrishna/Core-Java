package com.inheritance;

public class Manager {
	long salary;

}
