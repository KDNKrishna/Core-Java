package com.inheritance;

public class Employee extends Manager{


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee em = new Employee();
		em.salary = 1000;
		System.out.println("Salary:"+em.salary);
		
		Manager man = new Manager();
		man.salary=900;
		System.out.println("Manager:"+man.salary);

	}
}

