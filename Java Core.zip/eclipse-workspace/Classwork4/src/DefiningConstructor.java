
class Employee {
	
	int empno;
	String name;
	float sal;
	
	//Default Constructor
	Employee(){
		System.out.println("**********");
		empno = 0;
		name = "Sanjay";
		sal = 2424.4f;
	}
	
	// Overloading Constructors
	
	Employee(int empno, String name, float sal){
		this.empno = empno;
		this.name = name;
		this.sal = sal;
	}
	
	void displayDetails() {
		System.out.println(this.empno+" "+this.name+" "+this.sal);
	}
}

public class DefiningConstructor {
	

	public static void main(String[] args) {
		Employee emp1 = new Employee();
		Employee emp2 = new Employee(101, "Krish", 25f);
		Employee emp3 = new Employee();
		
		emp1.displayDetails();
		emp2.displayDetails();
		emp3.displayDetails();
		
	}

}
