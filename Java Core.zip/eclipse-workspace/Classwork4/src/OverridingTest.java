class F extends java.lang.Object {
	void display() {
		System.out.println("In class A");
	}
}

class E extends F{
	@Override // to provide metadata
	void display() {
		System.out.println("In class B");
	}
}


public class OverridingTest {

	public static void main(String[] args) {
		F ob = new F();
		ob.display();
		  

	}

}
