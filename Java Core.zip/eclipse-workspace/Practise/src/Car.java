
public class Car extends Vehicle{
	
	int not;

	Car(String tires) {
		super(tires);
		// TODO Auto-generated constructor stub
	}
	
	void liquid() {
		System.out.println("Liquid used here is "+not);
	}


}
