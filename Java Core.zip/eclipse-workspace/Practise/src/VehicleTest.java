
public class VehicleTest {

	public static void main(String[] args) {
		Vehicle sb = null;
		sb = new Bus("Cool");
		System.out.println("No of tires:"+sb.getTires());

	}

}
