package co.multithreading;

public class MultiThreads implements Runnable{
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}


	public static void main(String[] args) {
		Thread obj1 = new Thread("Krishna");
		Thread obj2 = new Thread("Kdn");
		obj1.start();
		obj2.start();
		obj1.setPriority(1);
		obj2.setName("Kondepati");
		int prior = obj1.getPriority();
		System.out.println(prior);
		System.out.println(obj1.getName());
		System.out.println(obj1.getId());
		System.out.println(obj2.getName());
		System.out.println(obj2.isAlive());
	

	}

	
}
