package co.multithreading;

public class WrapperTest {

	public static void main(String[] args) {
		Integer i1 = new Integer(56);
		Integer i2 = new Integer("767");
		Integer i3 = Integer.valueOf(746);
		Integer i4 = Integer.valueOf("985");
		
		
	

	}

}
