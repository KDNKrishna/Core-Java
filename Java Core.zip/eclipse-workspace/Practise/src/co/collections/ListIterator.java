package co.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

public class ListIterator {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		for(int i = 10; i <= 20; i++) {
			al.add(i);
		}
		
		System.out.println(al);
		iterate1(al);
		seperator();
		
		iterate2(al);
		seperator();
		
		iterate3(al);
		seperator();
		
		iterate4(al);
		seperator();
		
		iterate5(al);
		 
	}
	
	//One approach to display list (Normal for loop and get method) 
	static void iterate1(List<Integer> list) {
		System.out.println("using get method -- only applicable for list but not for set and all");
	    for (int i = 0; i < list.size(); i++) {
	    	Integer n = list.get(i);
	    	System.out.print(n+"  ");
	    }
	}
	
	// Another technique for displaying list is enchanced for loop or for each loop
	static void iterate2(List<Integer> list) {
		System.out.println("<<< using enhanced for loop");
		for (Integer n: list) {
			System.out.print(n+"  ");
		}
	}
	
	static void seperator() {
		try {
			System.out.println();
			Thread.sleep(2000);
		}
		
		catch(Exception e) {
			
		}
	}
	
	//Using Iterator
	static void iterate3(List<Integer> list) {
		System.out.println("using java.util.iterator");
		Iterator<Integer> ltr = list.iterator();
		while(ltr.hasNext()) {
			Integer n = ltr.next();
			System.out.print(n+"   ");
		}
	}
	
	static void iterate4(List<Integer> list) {
		System.out.println("using java.util.listIterator - only for java.util.List");
		java.util.ListIterator<Integer> lit = list.listIterator();
		while (lit.hasNext()) {
			Integer n = lit.next();
			System.out.print(n+"   ");
		}
		seperator();
		while(lit.hasPrevious()) {
			Integer n = lit.previous();
			System.out.print(n+"   ");
		}
	}
	
	static void iterate5(List<Integer> list) {
		System.out.println("<<< using java.util.Enumeration");
		Enumeration<Integer> en = Collections.enumeration(list); // Directly there is no interface for enumeration. So we are using collections
	    while (en.hasMoreElements()) {
	    	Integer n = en.nextElement();
	    	System.out.print(n+"   ");
	    }
	}
	
	

}
