package co.collections;

import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class HashSetTest {

	public static void main(String[] args) {
		//HashSet<String> names = new HashSet<String>(); // Displays data based on hashing (an unique id is given for every value. Based on that)
		TreeSet<String> names = new TreeSet<String>(new MyComparator()); // Displays output in ascending order. 
		//LinkedHashSet<String> names = new LinkedHashSet<String>(); // Based on the order, the output is displayed and does not store duplicates.
		System.out.println(names.add("Krishna"));
		System.out.println(names.add("Krishna"));
		names.add("K0");
		names.add("h0");
		names.add("hd");
		names.add("kd");
		names.add("usd");
		
		System.out.println(names); // Based on hashing, the data is displayed
		

	}

}

class MyComparator implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		int n = o1.compareTo(o2);
		if (n>0) {
			return -1;
		}
		else if (n<0) {
			return 1;
		}
		
		else {
			return 0;
		}
	}
	
}
