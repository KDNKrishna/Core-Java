package co.collections;

import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		
		ArrayList<Integer> names = new ArrayList<Integer>();
		System.out.println(names.size());
		
		names.add(1);
		names.add(2);
		names.add(3);
		names.add(4);
		names.add(5);
		names.add(6);
		names.add(1, 9);
		
		System.out.println(names); 
		System.out.println(names.contains(1));
		System.out.println(names.removeAll(names));
		System.out.println(names);

	}

}
