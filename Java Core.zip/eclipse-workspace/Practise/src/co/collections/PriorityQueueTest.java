package co.collections;

import java.util.PriorityQueue;

public class PriorityQueueTest {

	public static void main(String[] args) {
		PriorityQueue<String> queue = new PriorityQueue<String>();
		queue.add("Krish");
		queue.add("amit");
		queue.add("balu");
		queue.add("leela");
		queue.add("kishore");
		queue.offer("kdn");
		
		System.out.println(queue);
		System.out.println("head of the queue:"+queue.element());
		System.out.println(queue.remove());
		System.out.println(queue.poll());
        System.out.println(queue);
		System.out.println(queue.peek());
		System.out.println(queue);
	}

}
