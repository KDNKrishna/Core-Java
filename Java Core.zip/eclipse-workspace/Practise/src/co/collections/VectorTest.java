package co.collections;

import java.util.Vector;

public class VectorTest {

	public static void main(String[] args) {
		Vector <Integer> v = new Vector<>(); //initial capacity is 10
		//Vector <Integer> v = new Vector<>(5); //we can add default capacity i.e 5
		//Vector <Integer> v = new Vector<>(5, 3); //initial capacity is 5, increment capacity is 3
		System.out.println("Capacity:"+v.capacity());
		
		for (int i = 10; i<=20; i++) {
			v.add(i);
		}
		System.out.println(v.capacity());

	}

}
