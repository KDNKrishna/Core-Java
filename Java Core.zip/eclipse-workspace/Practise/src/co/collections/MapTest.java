package co.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapTest {

	public static void main(String[] args) throws InterruptedException {
		HashMap<String,Float> br = new HashMap<String, Float>();
		br.put("ID", 24f);
		
		Set<Map.Entry<String, Float>> entries = br.entrySet();
		Iterator <Map.Entry<String, Float>> it = entries.iterator();
		while(it.hasNext()) {
			Map.Entry<String, Float> entry = it.next();
			String key = entry.getKey();
			Float value = entry.getValue();
			System.out.println(key+"   "+value);
			Thread.sleep(1200);
		}

	}

}
