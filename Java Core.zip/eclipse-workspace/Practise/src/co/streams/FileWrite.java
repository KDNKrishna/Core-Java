package co.streams;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {

	public static void main(String[] args) throws IOException {
		//FileOutputStream fo = new FileOutputStream("src/co/streams/java.txt", true);
		/*String str = "!!!!!!-+";
		byte[] b = str.getBytes();
		fo.write(b);
		fo.close();
		
		// To write data to the file using FileWriter
		FileWriter fr = new FileWriter("src/co/streams/java.txt", true);
		fr.write("ABCDEGFHJFD");
		*/
		
		//To write using BufferedWriter
		String str = "Hello";
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/co/streams/java.txt"));
	    writer.write(str);
	    System.out.println("Data is written to the file");
	    writer.close();
	
	
	}

}
