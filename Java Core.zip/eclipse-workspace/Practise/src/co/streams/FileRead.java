package co.streams;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FileRead {

	public static void main(String[] args) throws IOException, InterruptedException {
		FileInputStream fi = new FileInputStream("src/co/streams/java.txt");
		/**System.out.println(fi.available()); // To read no of bytes available
	    System.out.println(fi.read()); // To read the ASCII value of the next character
	    System.out.println(fi.available()); // Now it will decrease one value. Bcz one character is already read.
	    System.out.println((char)fi.read()); // To read the actual character
	   */
		
		/*
	    //To read file contents byte by byte
	    int n = fi.read();
		while (n != -1) {
			System.out.print((char)n);
			Thread.sleep(120);
			n = fi.read();
			
		}*/
		
		/*
		//To read file contents completely
		byte [] b = new byte[fi.available()]; // Creates byte array with size of file
		fi.read(b);
		String str = new String(b); // Converting byte array to string
		System.out.println(str);*/
		
		
		// To read file contents line by line
		InputStreamReader source = new InputStreamReader(fi); // To convert byte stream to character stream
		BufferedReader br = new BufferedReader(source); 
		String line = br.readLine();
		while (line != null) {
			System.out.println(line);
			Thread.sleep(2000);
			line = br.readLine();
		}
		
		
		// TO read file word by word
		InputStreamReader source2 = new InputStreamReader(fi); // To convert byte stream to character stream
		BufferedReader bre = new BufferedReader(source2); 
		String line1 = bre.readLine();
		while (line1 != null) {
			StringTokenizer st = new StringTokenizer(line1);
			while(st.hasMoreElements()) {
				System.out.println(st.nextToken());
				Thread.sleep(2000);
				
			}
			Thread.sleep(2000);
			line = br.readLine();
		}
		
		fi.close();

	}

}
