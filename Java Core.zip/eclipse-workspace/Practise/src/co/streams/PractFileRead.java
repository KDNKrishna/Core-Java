package co.streams;

import java.io.FileInputStream;

public class PractFileRead {

	public static void main(String[] args) throws Exception{
		FileInputStream st = new FileInputStream("src/co/streams/java.txt");
		System.out.println("No of bytes:"+st.available());
		System.out.println("No of bytes:"+(char)st.read());
		
		
		//How to read file content byte by byte
		int n = st.read();
		while(n != -1) {
			System.out.print((char)n);
			Thread.sleep(150);
			n = st.read();
		}
		
		
		//How to read content completely at a time
		byte [] b = new byte[st.available()];
		st.read(b);
		String str = new String(b);
		System.out.println(str);
		st.close();

	}

}
