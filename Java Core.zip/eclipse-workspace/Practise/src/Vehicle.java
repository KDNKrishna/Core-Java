
public abstract class Vehicle {

	String tires;
	
	Vehicle(String tires){
		this.tires = tires;
	}
	
	public String getTires() {
		return tires;
	}

	public void setTires(String tires) {
		this.tires = tires;
	}
	
	abstract void liquid();
	
	

}
