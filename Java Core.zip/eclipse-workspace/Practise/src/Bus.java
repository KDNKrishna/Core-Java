
public class Bus extends Vehicle{
	
	int not;
	
	Bus(String tires){
		super(tires);
	}
	
	void liquid() {
		System.out.println("The liquid used here is = "+not * not);
	}

}
