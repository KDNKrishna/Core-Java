package co.Collections;

import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Map;

public class HashtableTest {
	
	String name;
	double marks;

	public static void main(String[] args) {
		Map<String, Double> map = new Hashtable<String, Double>();
		map.put("Krishna", 96.0);
		map.put("Edureka", 95.0);
		map.put("Kdn", 92.0);
		map.put("Sri", 91.0);
		map.put("Kri", 98.0);
		
        System.out.println(map);
        
       
		for(Map.Entry m:map.entrySet()){  
			System.out.println(m.getKey()+" "+m.getValue()); 
		}  
	    
		//To get max value
		System.out.println("Maximum Value is:");
		Double max = Collections.max(map.values());
		System.out.println(max);	   
			  
			  
	}

}
