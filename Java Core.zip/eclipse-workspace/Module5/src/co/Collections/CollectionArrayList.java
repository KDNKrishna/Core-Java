package co.Collections;

import java.util.ArrayList;

public class CollectionArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(0, 1);
		list1.add(1, 2);
		list1.add(2, 3);
		list1.add(3, 4);
		list1.add(4, 5);
		list1.add(5, 6);
		list1.add(6, 7);
		list1.add(7, 8);
		list1.add(8, 9);
		list1.add(9, 10);
		
		System.out.println(list1);

	}

}
