package co.Collections;

import java.util.HashMap;

public class EmployeerecordsUsingHashMap {


	public static void main(String[] args) {
		HashMap<String, String> map1 = new HashMap<String, String>();
		try {
			System.out.println("Employee Records are");
			
			map1.put("Balu", "Developer");
			map1.put("Anil", "Software Engineer");
			map1.put("Christian", "Tester");
			map1.put("Deepak", "DevOps");
			map1.put("Eeshwar", "SysAdmin");
			
			
			System.out.println(map1);
		}
		
		catch(Exception e) {
			System.out.println("Exception is "+e);
		}
		

	}

}
