package co.Collections;

public class WrapperClassesTest {

	public static void main(String[] args) {
		Integer i1 = new Integer(5090);
		Integer i2 = new Integer("4848");
		Integer i3 = Integer.valueOf(509);
		Integer i4 = Integer.valueOf("985489");

		
		//To get primitive value from object
		int n = i1.intValue();
		System.out.println(n);
		
		//Boxing (Converting primitive data to wrapper)
		int n1 = 98;
		Integer n2 = n1;
		System.out.println("Boxing value :"+n2);
		
		//Unboxing (Converting wrapper to primitive data type)
		int n3 = n2;
		System.out.println("Unboxing value :"+n3);
	}

}
