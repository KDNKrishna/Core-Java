import java.util.Scanner;

public class FirstAssignment {
	
	//First Assignment
	void display(int id[], String name[], double salary[]) {
		System.out.println("ID           Name            Salary");
		int length = id.length;
		for (int i = 0; i< length; ++i) {
			System.out.println(id[i] + "            "+name[i]+"            "+salary[i]);
		}
	}
	
	//Second Assignment
	void display(int id[], String name[]) {
		System.out.println("ID           Name");
		int length = id.length;
		for (int i = 0; i<length; ++i) {
			System.out.println(id[i] + "            "+name[i]);
		}
		
	}
	
	// Third Assigment
	void display(String search[], int id[], String name[], double salary[] ) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the user name:");
		String input = sc.next();
		System.out.println("ID           Name           Salary");
		int length = id.length;
		for (int i = 0; i< length; ++i) {
			if (input.contains(name[i])) {
				System.out.println(id[i] + "            "+name[i]+"            "+salary[i]);
			}
			
		}
			
	}

	public static void main(String[] args) {
		int id[] = new int[5];
		String name[] = new String[5];
		double salary[] = new double[5];
		String search[] =  new String[5];
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Employee details are");
		
		for (int i = 0; i<5; i++) {
			System.out.println("Enter employee record ("+(i+1)+")");
			id[i] = sc.nextInt();
			name[i] = sc.next();
			salary[i] = sc.nextDouble();
			
		}
		
		FirstAssignment c = new FirstAssignment();
		c.display(id, name, salary);
		c.display(id, name);
		c.display(search, id, name, salary);
		
	}

}
