
final class Savings extends Account {
	float roi;
	double minBal = 500;

	
	void display(double amount) {
		super.deposit(amount);
	}
	
	void withdraw(double amount) {
		super.withdraw(amount);
	}
	
	void addInterest(int months) {
		bal = bal + (months * 0.04);
	}
	
}
