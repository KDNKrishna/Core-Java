
final class Current extends Account{
	
	double minBal = 500;
	
	void display(double amount) {
		super.deposit(amount);
	}
	
	void withdraw(double amount) {
		super.withdraw(amount);
	}

}
