import java.util.Scanner;

abstract class Account {

	
	long accNum;
	String name;
	double bal;
	
	//Method to deposit
	void deposit(double amount) {
		bal = bal + amount;
		System.out.println("Rs. "+amount+" "+ "Credited; Balance:"+bal);
		
	}
	
	//Method to withdrawl
	void withdraw(double amount) {
		if (bal > amount) {
			bal = bal + amount;
			System.out.println("Rs. "+amount+" "+ "Debited; Balance:"+bal);
		}
		
		else {
			System.out.println("Insufficient Balance");
		}
	}//withdraw
	
	
	public void displayAccountDetails()
	{
		System.out.println("Displaying account details...");
		System.out.println("Account no " + accNum );
		System.out.println("Name " + name );
	}
	
	public void displayBalance()
	{
		System.out.println("Balance is "+bal);
	}
	

	public static void main (String args[])
	{
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter the type of account you want to create :");
		String account_type = sc.next();
		
		//Runtime polymorphism.
		Account acct;		
		
		if (account_type.equalsIgnoreCase("SB"))
			acct = new Savings();
		else
			acct = new Current();
		
		
		System.out.println("Enter account number...");
		acct.accNum = sc.nextLong();
		
		
		System.out.println("Enter Name...");
		acct.name = sc.next ();
	
		System.out.println("Enter Deposit...");
		double amount = sc.nextDouble();
		
		acct.displayAccountDetails();
		
		acct.deposit(amount);
		acct.deposit(1000);
		acct.withdraw(200);
		
		
		
		acct.displayBalance();	
		
	}

}
