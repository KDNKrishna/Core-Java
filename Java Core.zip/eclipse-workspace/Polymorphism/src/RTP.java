
class Shape{
	Shape(){
		System.out.println("Shape object created");
	}
	
	void drawn() {
		System.out.println("Drawing a shape");
	}
}

class Rectangle extends Shape{
	Rectangle(){
		System.out.println("Rectangle object created");
	}
	
	//Overriding
	void drawn() {
		System.out.println("Drawing a rectangle");
	}
}

class Triangle extends Shape{
	Triangle(){
		System.out.println("Triangle object created");
	}
	
	//Overriding
	void drawn() {
		System.out.println("Drawing a triangle");
	}
}

public class RTP {
	public static void main(String[] args) {
		Shape s;
		// Polymorphism is nothing but a reference of a parent can be pointed to the object of child.
		s = new Rectangle();
		s.drawn();
		
		s = new Triangle();
		s.drawn();
		
	}

}
