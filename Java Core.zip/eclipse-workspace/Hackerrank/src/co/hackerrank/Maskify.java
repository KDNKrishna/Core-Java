package co.hackerrank;

import java.util.Scanner;

public class Maskify {
	
	Scanner sc = new Scanner(System.in);
	Long Number = sc.nextLong();
	String CreditCardNumber = Number+"";
	//char val[] = {} ;
	
	public String maskify() {
		StringBuilder sb = new StringBuilder(CreditCardNumber);
		if (CreditCardNumber.length() < 6) {
			return CreditCardNumber;
		}
		
		else if(CreditCardNumber.toCharArray() != null) {
			return CreditCardNumber;
		}
		return CreditCardNumber;
		
	}
			

	public static void main(String[] args) {
		Maskify mask = new Maskify();
		mask.maskify();

	}

}
