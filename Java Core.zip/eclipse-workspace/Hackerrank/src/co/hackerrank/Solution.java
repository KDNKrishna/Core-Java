package co.hackerrank;
import java.util.*;
public class Solution {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner myObj = new Scanner(System.in);
        int n= myObj.nextInt();
        int d = myObj.nextInt();
        for (int i = 1; i<=d; i++){ 
        	for (int j = 2; j<=d; j++) {
        		System.out.print(d);
        	}
        	 System.out.println(n);
        }
    }
}
