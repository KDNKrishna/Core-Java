package edu.forLoop;

public class TablesOfTen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
		int n = 100;
		
		for (i=10; i <= n; i++) {
			if (i%10== 0) {
				System.out.println(i);
			}
		}
		

	}

}
