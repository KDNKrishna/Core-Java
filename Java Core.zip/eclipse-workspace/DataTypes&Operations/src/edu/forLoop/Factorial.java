package edu.forLoop;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, factNum = 1;
		int num = 9;
		
		for (a = 1; a<=num; a++) {
			factNum = factNum * a;
		}
		
		System.out.println("Factorial of "+num+" is: "+factNum);    

	}

}
