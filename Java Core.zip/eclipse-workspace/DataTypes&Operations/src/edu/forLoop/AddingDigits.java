package edu.forLoop;

public class AddingDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
		int n = 123;
		
		for (i =0; n!=0; n/=10) {
			i+=n%10;
		}
		
		System.out.println("Adding digits of a number:"+i);

	}

}
