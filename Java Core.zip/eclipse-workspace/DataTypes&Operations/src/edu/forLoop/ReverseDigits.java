package edu.forLoop;

public class ReverseDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 123456789, reverseNum = 0;

        for(;num != 0; num /= 10) {
            int digit = num % 10;
            reverseNum = reverseNum * 10 + digit;
        }

        System.out.println("Reversed Number: " + reverseNum);

	}

}
