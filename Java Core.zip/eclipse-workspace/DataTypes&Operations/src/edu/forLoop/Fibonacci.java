package edu.forLoop;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f1 = 0, f2 = 1, f3, total=10, i;
		
		System.out.print("Fibonacci Series :"+f1+" "+f2);
		
		for (i = 2; i<total; i++) {
			f3 = f1+f2;
			System.out.print(" "+f3);
			f1 = f2;
			f2 = f3;
		}
		

	}

}
