package edu.ifCondition;

public class LargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int firstNumber = 33;
		int secondNumber = 450;
		
		if (firstNumber > secondNumber) {
			System.out.println("firstNumber is the largest");
		}
		
		else {
			System.out.println("secondNumber is largest");
		}

	}

}
