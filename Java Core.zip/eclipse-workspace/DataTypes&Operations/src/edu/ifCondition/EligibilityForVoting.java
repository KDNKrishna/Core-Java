package edu.ifCondition;

public class EligibilityForVoting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int age = 15;
		int age1 = 20;
		
		if (age>18) {
			System.out.println("age is eligible to vote");
		}
		
		if (age1>18) {
			System.out.println("age1 is eligible to vote");
		}

	}

}
