package edu.ifCondition;

public class EvenOrOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int divisibleByTwo = 646;
		int notDivisibleByTwo = 989;
		
		if (divisibleByTwo%2 == 0) {
			System.out.println("The given number is even");
		}
		
		else {
			System.out.println("The given number is odd");
		}
		
		if (notDivisibleByTwo%2 == 0) {
			System.out.println("The second given number is even");
		}
		
		else {
			System.out.println("The second given number is odd");
		}

	}

}
