package edu.ifCondition;

public class PositiveNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b =-20;
		int c = 0;
		
		if (a>0) {
			System.out.println("a is Positive");
		}
		
		else if (a<0) {
			System.out.println("a is Negative");
		}
		
		else {
			System.out.println("a is zero");
		}
		
		if (b>0) {
			System.out.println("b is Positive");
		}
		
		else if (b<0) {
			System.out.println("b is Negative");
		}
		
		else {
			System.out.println("b is zero");
		}
		
		if (c>0) {
			System.out.println("c is Positive");
		}
		
		else if (c<0) {
			System.out.println("c is Negative");
		}
		
		else {
			System.out.println("c is zero");
		}

	}

}
