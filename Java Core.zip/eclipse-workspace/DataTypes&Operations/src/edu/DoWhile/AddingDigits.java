package edu.DoWhile;

public class AddingDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 0;
		int n = 56576;
		
		do {
            i+=n%10;
			n/=10;
		}
	
		while (n!= 0);
		System.out.println("Adding digits of a number:"+i);
		

	}

}
