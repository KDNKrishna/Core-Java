package edu.DoWhile;

public class TablesOfTen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10;
		int n = 100;
		
		do {
			if (i%10 == 0) {
				System.out.println(i);
			}
			i++;
		}
		while (i<=n);

	}

}
