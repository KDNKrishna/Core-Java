package edu.DoWhile;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1, factNum = 1;
		int num = 7;
		
		do {
			factNum = factNum *a;  
			a++;
		}
		while (a<=num);
			
		System.out.println("Factorial of "+num+" is: "+factNum);  

	}

}
