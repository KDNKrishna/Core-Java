package edu.dataTypes.ArthimeticOperations;

public class Double {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double f = 5.50;
		double ff = 7.80;
		double add = f+ff;
		double sub = f-ff;
		double mul = f*ff;
		double div = ff/f;
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    f++;
	    System.out.println("Incrementing:"+f);
	    
	    //Decrementing
	    ff--;
	    System.out.println("Decrementing:"+ff);


	}

}
