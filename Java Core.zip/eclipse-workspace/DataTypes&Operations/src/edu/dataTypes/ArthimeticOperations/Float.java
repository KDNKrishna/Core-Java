package edu.dataTypes.ArthimeticOperations;

public class Float {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		float f = 5.5f;
		float ff = 7.8f;
		float fff = 2.85f;
		float add = f+ff+fff;
		float sub = f-ff-fff;
		float mul = f*ff;
		float div = ff/f;
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    f++;
	    System.out.println("Incrementing:"+f);
	    
	    //Decrementing
	    ff--;
	    System.out.println("Decrementing:"+ff);

	}

}
