
package edu.dataTypes.ArthimeticOperations;

public class Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c = 'a';
		char ch = 'b';
		char add = (char) (c+ch);
		char sub = (char) (c-ch);
		char mul = (char) (c*ch);
		char div = (char) (c/ch);
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    c++;
	    System.out.println("Incrementing:"+c);
	    
	    //Decrementing
	    ch--;
	    System.out.println("Decrementing:"+ch);

	}


}
