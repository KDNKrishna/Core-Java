package edu.dataTypes.ArthimeticOperations;

public class Byte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte i = 100;
		byte y = 20;
		byte add = (byte) (i+y);
		byte sub = (byte) (i-y);
		byte mul = (byte) (i*y);
		byte div = (byte) (y/i);
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    i++;
	    System.out.println("Incrementing:"+i);
	    
	    //Decrementing
	    y--;
	    System.out.println("Decrementing:"+y);

	}

}
