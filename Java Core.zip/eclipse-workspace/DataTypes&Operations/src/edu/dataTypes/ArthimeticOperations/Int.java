package edu.dataTypes.ArthimeticOperations;

public class Int {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10;
		int y = 20;
		int add = i+y;
		int sub = i-y;
		int mul = i*y;
		int div = y/i;
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    i++;
	    System.out.println("Incrementing:"+i);
	    
	    //Decrementing
	    y--;
	    System.out.println("Decrementing:"+y);

	}
}
