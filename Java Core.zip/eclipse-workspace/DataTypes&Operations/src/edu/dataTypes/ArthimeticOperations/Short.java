package edu.dataTypes.ArthimeticOperations;

public class Short {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short i = 10000;
		short y = 20000;
		short add = (short) (i+y);
		short sub = (short) (i-y);
		short mul = (short) (i*y);
		short div = (short) (y/i);
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    i++;
	    System.out.println("Incrementing:"+i);
	    
	    //Decrementing
	    y--;
	    System.out.println("Decrementing:"+y);

	}

}
