package edu.dataTypes.ArthimeticOperations;

public class Long {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long i = 230000000;
		long y = 440000000;
		long add = i+y;
		long sub = i-y;
		long mul = i*y;
		long div = y/i;
		// Adding of 2 numbers
	    System.out.println("Addition:"+add);
	    
	    // Subtracting of 2 numbers
	    System.out.println("Subtraction:"+sub);
	    
	    // Multiplication of 2 numbers
	    System.out.println("Multiplication:"+mul);
	    
	    // Division of 2 numbers
	    System.out.println("Division:"+div);
		
	    //Incrementing 
	    i++;
	    System.out.println("Incrementing:"+i);
	    
	    //Decrementing
	    y--;
	    System.out.println("Decrementing:"+y);


	}

}
