package edu.WhileLoop;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f1 = 1, f2 = 1, f3, total = 10, i = 2;
		
		System.out.print("Fibonacci Series :"+f1+" "+f2);
		
		while(i<=total) {
			f3 = f1+f2;
			System.out.print(" "+f3);
			f1 = f2;
			f2 = f3;
			
			i++;
		}

	}
	
}
	