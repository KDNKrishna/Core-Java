package edu.WhileLoop;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 1, factNum = 1;
		int num = 7;
		
		while (a<=num) {
			factNum = factNum *a;  
			a++;
    
	}
		System.out.println("Factorial of "+num+" is: "+factNum);  

	}

}
