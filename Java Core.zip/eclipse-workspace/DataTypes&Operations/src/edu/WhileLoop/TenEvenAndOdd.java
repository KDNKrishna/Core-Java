package edu.WhileLoop;

public class TenEvenAndOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		
		while (i<20) {
			if (i%2 == 0) {
				System.out.println("Even Number is"+" "+i);
			}
			
			else {
				System.out.println("Odd Number is"+" " +i);
			}
			
			i++;
		}

	}

}
