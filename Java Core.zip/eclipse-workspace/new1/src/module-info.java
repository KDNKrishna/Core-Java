package co.cc.enlightensoft.codility.self;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * 
 * 1A 3C 2B 40G 5A
 * 
*/
public class Solution_AirplanSeatAllocation {

public int solution(int N, String S) {
 int result = 0;

Map<Integer, List> totalSeat = new HashMap<>();
 String[] splitted = null;
 if (S.trim().length() > 0) {

splitted = S.split(" ");
 Arrays.sort(splitted);
 }
 for (int rowCount = 1; rowCount <= N; rowCount++) {

List row = new ArrayList<>(3);

List list1 = new ArrayList<>(3);
 list1.add(0);
 list1.add(0);
 list1.add(0);

List list2 = new ArrayList<>(4);
 list2.add(0);
 list2.add(0);
 list2.add(0);
 list2.add(0);

List list3 = new ArrayList<>(3);
 list3.add(0);
 list3.add(0);
 list3.add(0);

row.add(list1);
 row.add(list2);
 row.add(list3);

totalSeat.put(rowCount, row);
 if (S.trim().length() > 0) {
 for (int j = 0; j < splitted.length; j++) {
 String code = splitted[j];

String subC = code.substring(1);

int currRow = Integer.parseInt(code.substring(0, 1));
 if (currRow == rowCount) {

switch (subC) {
 case "A":
 totalSeat.get(rowCount).get(0).set(0, 1);
 break;
 case "B":
 totalSeat.get(rowCount).get(0).set(1, 1);
 break;
 case "C":
 totalSeat.get(rowCount).get(0).set(2, 1);
 break;
 case "D":
 totalSeat.get(rowCount).get(1).set(0, 1);
 break;
 case "E":
 totalSeat.get(rowCount).get(1).set(1, 1);
 break;
 case "F":
 totalSeat.get(rowCount).get(1).set(2, 1);
 break;
 case "G":
 totalSeat.get(rowCount).get(1).set(3, 1);
 break;
 case "H":
 totalSeat.get(rowCount).get(2).set(0, 1);
 break;
 case "J":
 totalSeat.get(rowCount).get(2).set(1, 1);
 break;
 case "K":
 totalSeat.get(rowCount).get(2).set(2, 1);
 break;
 }
 }
 }
 }

}

for (int rowCount = 1; rowCount <= N; rowCount++) {
 if (!totalSeat.get(rowCount).get(0).contains(1)) {
 // System.out.println(rowCount + "List1");
 result++;
 }

if (!totalSeat.get(rowCount).get(1).contains(1)) {
 // System.out.println(rowCount + "List2");
 result++;
 } else if (totalSeat.get(rowCount).get(1).get(1) == 0 && totalSeat.get(rowCount).get(1).get(2) == 0) {
 if (totalSeat.get(rowCount).get(1).get(0) == 0 || totalSeat.get(rowCount).get(1).get(3) == 0) {
 // System.out.println(rowCount + "list2");
 result++;
 }
 }

if (!totalSeat.get(rowCount).get(2).contains(1)) {
 // System.out.println(rowCount + "");
 result++;
 }

}
 return result;
 }

public boolean solution1(int[] A) {
 boolean result = true;

return result;
 }
}