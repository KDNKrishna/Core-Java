package new1;

public class UnderstandingStatic {
	
	public int a;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnderstandingStatic un = new UnderstandingStatic();
		int b = un.a = 1;
		System.out.println(b);
		
		
		

	}

}
