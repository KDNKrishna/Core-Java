package new1;

public class HelloWorld {

	     public static void main(String[] args)
	    {
	        System.out.println("dog " + FindMaxInsert("dog"));
	        System.out.println("aabab " + FindMaxInsert("aabab"));
	        System.out.println("aa " + FindMaxInsert("aa"));
	        System.out.println("a " + FindMaxInsert("a"));
	        System.out.println("baaa " + FindMaxInsert(""));
	     }
	    private static int FindMaxInsert(String str)
	{
				int amount = 0;
				final char forbiddenChar = 'a';
				if (str.contains("aaa"))
				{
					amount = -1;
				}

				else
				{
					if (str.length() == 1)
					{
						if (str.charAt(0) == forbiddenChar)
						{
							amount = 1; //A - > aA || Aa
						}
						else
						{
							amount = 4; // B - > aaBaa
						}
					}
					else if (str.length() == 2)
					{
						if ((str.charAt(0) == forbiddenChar && str.charAt(1) != forbiddenChar) || (str.charAt(0) != forbiddenChar && str.charAt(1) == forbiddenChar))
						{
							amount = 3; // A B || B A -> aABaa || aaBAa
						}
					}

					else if (str.length() > 2) //prevnet  against empty string
					{
						if (str.charAt(0) != forbiddenChar)
						{
							amount += 2;
						}
						if (str.charAt(str.length() - 1) != forbiddenChar)
						{
							amount += 2;
						}

						for (int i = 0; i < str.length() - 2; i += 2) //search insert between
						{
							char first = str.charAt(i);
							char middle = str.charAt(i + 1);
							char last = str.charAt(i + 2);


							if (first == forbiddenChar && middle == forbiddenChar && last == forbiddenChar)
							{
								amount += 0; // A A A - > cant
							}


							else if (first == forbiddenChar && middle == forbiddenChar && last != forbiddenChar)
							{
								amount += 0; // A A B  -> cant
							}


							else if (first == forbiddenChar && middle != forbiddenChar && last == forbiddenChar)
							{
								amount += 2; // A B A  -> AaBaA
							}


							else if (first == forbiddenChar && middle != forbiddenChar && last == forbiddenChar)
							{
								amount += 0; // B A A   -> cant
							}


							else if (first == forbiddenChar && middle != forbiddenChar && last != forbiddenChar)
							{
								amount += 3; // A B B -> AaBaaB
							}


							else if (first != forbiddenChar && middle == forbiddenChar && last != forbiddenChar)
							{
								amount += 1; // B A B  - > BaAB || BAaB
							}


							else if (first != forbiddenChar && middle != forbiddenChar && last == forbiddenChar)
							{
								amount += 3; // B B A  -> BaaBaA || BaaBAa
							}


							else if (first != forbiddenChar && middle != forbiddenChar && last != forbiddenChar)
							{
								amount += 4; // B B B -> BaaBaa
							}
						}
					}
				}

				return amount;

	}
	}



