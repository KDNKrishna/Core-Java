package main.sample;

public class HelloWorld {
	public static void main(String[] args) {
		int a = 0;
		long b = 0;
		float c = 0.0f;
		
		
		int f[] = new int[4];
	}

}
