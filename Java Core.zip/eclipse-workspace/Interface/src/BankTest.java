
public class BankTest {

	public static void main(String[] args) {
		Bank bt = null;
		bt = new SBI();
		System.out.println(bt.n);
		System.out.println(Bank.n);
		System.out.println(SBI.n);

	}

}
