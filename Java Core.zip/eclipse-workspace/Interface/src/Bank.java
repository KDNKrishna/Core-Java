
public interface Bank {
	
	int n = 10; //By default they are final variables 
	void deposit(float amt);
	void withdraw (float amt);// By default they are abstract methods

}
