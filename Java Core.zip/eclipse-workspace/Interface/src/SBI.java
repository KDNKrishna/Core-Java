
public class SBI implements Bank {

	public void deposit(float amt) {
		System.out.println("Deposit");
		
	}
// If methods in parent class are public, the same should be applicable for child class
	public void withdraw(float amt) {
		System.out.println("Withdraw");
		
	}
	
	

}
