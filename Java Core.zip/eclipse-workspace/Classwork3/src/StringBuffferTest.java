

public class StringBuffferTest {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		System.out.println(sb+"Size :"+sb.length()+" "+sb.capacity());
		
		sb.append("krishhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
		System.out.println(sb.length()+" "+sb.capacity());

	}

}
