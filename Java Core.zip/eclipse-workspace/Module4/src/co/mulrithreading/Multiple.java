package co.mulrithreading;

public class Multiple extends Thread {
	
	Multiple(){
		start();
	}
	
	public void run() {
		try {
			int table = 5, i = 0;
			while (i < 10) {
				System.out.println(table+"*"+(i+1)+"="+" "+Math.multiplyExact(table, i+1));
				i++;
			}
		}
		
		catch (Exception e) {
			System.out.println("Exception is :"+e);
		}
	}
	
	

	public static void main(String[] args) {
		new Multiple();
		
		// Main Thread
		try {
			Thread.sleep(2000);
			for (int i = 0; i<=40; i++) {
				if (i%2 == 0) {
					System.out.println("Main Thread is :"+i);
					Thread.sleep(200);
				}
			}
		}
		
		catch(Exception e) {
			System.out.println("Exception is :"+e);
		}
		

	}

}
