package co.allMethods;

public class OldPackage {
	
	int a = 10, b = 20, revNum = 0, num = 1256, fact = 1, factNum = 6;
	
	public void subtraction() {
		int diff = b -a ;
		System.out.println("Subtraction is "+diff);
	}
	
	public void multiply() {
		int mul = a * b;
		System.out.println("Multiplication is "+mul);
	}
	
	public void divide() {
		int div = b/a;
		System.out.println("Division is "+div);
	}
	
    public void revNum() {
    	while(num != 0) {
    		int digit = num %10;
    		revNum = revNum * 10 + digit;
    		num = num / 10;
    		
    	}
    	System.out.println("Reverse Number is "+revNum);
    }
	
	public void factorial() {
		for (int i = 1; i<= factNum; i++) {
			fact = fact * i;
		}
		System.out.println("Factorial of 6 is :"+fact);
	}

}
