package co.newPackage;

import co.allMethods.*;

public class NewPackage {

	public static void main(String[] args) {
		OldPackage obj = new OldPackage();
		obj.subtraction();
		obj.multiply();
		obj.divide();
		obj.factorial();
		obj.revNum();
		
		
		

	}

}
