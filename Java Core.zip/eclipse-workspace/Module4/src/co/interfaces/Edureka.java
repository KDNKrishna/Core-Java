package co.interfaces;

interface Queue {
	
	StringBuffer a = new StringBuffer("Edureka");

	
	void insert();
	
	void delete();

}

class Edureka implements Queue {

	
	public void insert() {
		a.insert(3, "123");
		System.out.println(a);
		
	}

	
	public void delete() {
		a.delete(3, 6);
		System.out.println(a);
		
		
	}
	
	public static void main(String[] args) {
		Edureka q = new Edureka();
		q.insert();
		q.delete();
	}
	
}
