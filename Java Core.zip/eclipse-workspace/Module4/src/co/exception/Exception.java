package co.exception;

public class Exception {
	
	
	/*void except() {
		
		int arr[] = {100};
		
		System.out.println("Access the array = "+arr[101]);
		
	}*/ //While executing this method, we will get an exception
	
	void exception() {
		int arr[] = {200};
		
		try {
			System.out.println("Access the array = "+arr[201]);
		}
		
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("The index you have entered is invalid");
		}
	} // Using try and catch, the program gets executed without errors and it can be able to handle all those errors.

	public static void main(String[] args) {
		Exception obj = new Exception();
		obj.exception();
		

	}

}
