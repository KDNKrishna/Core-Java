
public class AbstractTest {
	
	public static void main(String[] args) {
		Shape sh = null;
		//sh = new Shape();// Cannot instaantaite abstract method with object.
		sh = new Circle("Blue", 25f);
		System.out.println("Color = "+sh.getColor());
		sh.area();
		System.out.println("--------------------");
		sh = new Rectangle("Yellow", 2, 5);
		System.out.println("Color ="+sh.getColor());
		sh.area();
	}

}
