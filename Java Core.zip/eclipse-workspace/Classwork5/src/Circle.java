
public class Circle extends Shape{
	
	float radius;
	
	Circle(String color, float radius) {
		super(color);
		this.radius = radius;
		// TODO Auto-generated constructor stub
	}
	
	void area() {
		System.out.println("Area of the circle ="+(Math.PI*radius*radius));
	}

	
	
	

}
 