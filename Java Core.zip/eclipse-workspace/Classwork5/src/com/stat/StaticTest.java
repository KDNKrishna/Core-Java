package com.stat;

public class StaticTest {

	public static void main(String[] args) {
		

	}

}
